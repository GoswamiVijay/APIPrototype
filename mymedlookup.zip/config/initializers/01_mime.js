module.exports = function() {
  // Define custom MIME types.  Consult the mime module [documentation](https://github.com/broofa/node-mime)
  // for additional information.
  /*
  this.mime.define({
    'application/x-foo': ['foo']
  });
  */
}
