var expect   = require("chai").expect;
describe("ClassName", function(){
    describe("MethodName", function() {
        it("Description of the case we are testing", function () {
            expect(true).equal(true);
        }); 
    });
});